import React from 'react';
import './App.css';
import FetchFromApi from './components/fetchFromApi';


const App = () => {
  return (
    <div className="App">
     <FetchFromApi/>
    </div>
  );
}

export default App;
