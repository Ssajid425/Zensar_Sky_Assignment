import React, { useEffect, useState } from 'react'
const FetchFromApi = () => {
    const [ data ,setData] = useState([])

    const getData = async() => {
        const response = await fetch("https://api.spacexdata.com/v4/launches/past");
        setData(await response.json());
        
    }
    useEffect(()=> {
        getData();
    
    }, [] );
    return(
  <>
         <h1 className="text centre">SpaceX Past Launches </h1>
         <div className="container-fluid mt-5">
          <div className="row text-center">
            {
                data.map((selectData) =>{
                    return(
                        <div className="col-10 col-md-4 mt-5" key = {selectData.id}>
                        <div className="card p-2">
                            <div className="d-flex align-items-center">
                              <div className="image"><img src = "https://images2.imgbox.com/3d/86/cnu0pan8_o.png" class="rounded" width="155"/></div>
                              <div className="m-3 w-100">
                                  <h4 className="mb-0 mt-0 text-left">{selectData.name}</h4> <span className="text-left">{selectData.details}</span>
                                  <div className="p-2 mt-2 bg-primary d-flex justify-content-between rounded text-white status">
                                      <div className="d-flex flex-column"><span className="Flight number">Flight No.</span>{selectData.fight_number}</div> 
                                      <div className="d-flex flex-column"><span className="followers">Success/Failure</span>{selectData.success}</div> 
                                      <div className="d-flex flex-column"><span className="ratingd">Ratings</span>4.5</div> 
                                  </div>
                              </div>
                            </div>
                        </div>
                    </div> 
                    )
                }
                )
            }                                      
        </div>  
      </div>
  </>
    )
}
export default FetchFromApi;